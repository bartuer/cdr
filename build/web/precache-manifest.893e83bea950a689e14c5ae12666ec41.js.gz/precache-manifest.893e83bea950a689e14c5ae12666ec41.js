self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6c90d852bd5b100adc3d89d261ef9af1",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/paragraph-disabled-inverse.svg"
  },
  {
    "revision": "c0e351a301530dca962d",
    "url": "ide.0.9c27f8.js"
  },
  {
    "revision": "d2012a2d717fe10b3f45",
    "url": "ide.main.9c27f8.css"
  },
  {
    "revision": "d2012a2d717fe10b3f45",
    "url": "ide.main.9c27f8.js"
  },
  {
    "revision": "820b98aba39731cb9f0b",
    "url": "ide.3.9c27f8.js"
  },
  {
    "revision": "47c2d1e0e53e127f63e1",
    "url": "ide.4.9c27f8.js"
  },
  {
    "revision": "f18c544de4de0e63abcf",
    "url": "ide.5.9c27f8.js"
  },
  {
    "revision": "b1157c0ba46eca94c538",
    "url": "ide.6.9c27f8.js"
  },
  {
    "revision": "21afa9ace91f25ce497f",
    "url": "ide.7.9c27f8.js"
  },
  {
    "revision": "ce3386960433dbf36024",
    "url": "ide.8.9c27f8.js"
  },
  {
    "revision": "4604fa207fbdd8a35549",
    "url": "ide.9.9c27f8.js"
  },
  {
    "revision": "f8f4d843120eff950dd7",
    "url": "ide.10.9c27f8.js"
  },
  {
    "revision": "41320e32b10812b22884",
    "url": "ide.11.9c27f8.js"
  },
  {
    "revision": "11ba0967be5d2509aed03ba771ef33ee",
    "url": "lib/vscode/src/vs/workbench/contrib/preferences/electron-browser/media/preferences-editor.svg"
  },
  {
    "revision": "3c506d7542ed19cc92b5040a6c8236a6",
    "url": "lib/vscode/src/vs/workbench/contrib/preferences/electron-browser/media/preferences-editor-inverse.svg"
  },
  {
    "revision": "3630443ef9da056eca9e831878d90612",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/letterpress-dark.svg"
  },
  {
    "revision": "185f86f7b7407b99763fd063037c9890",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/letterpress-hc.svg"
  },
  {
    "revision": "e8989fbd1eaecea426961e5337a784e4",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/letterpress.svg"
  },
  {
    "revision": "da3aab75c00830c8a5b3e62b732ad9d8",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/back-tb.png"
  },
  {
    "revision": "fe3f8eb4855d74cf0f6f143f02d3952f",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/forward-tb.png"
  },
  {
    "revision": "737335eea7a691ed2846f4c007af6ae1",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/breadcrumbscontrol.css"
  },
  {
    "revision": "bab7d76b2c3a17a64fe5ab3479556f38",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/editordroptarget.css"
  },
  {
    "revision": "fe7c661e565f81b86a13a41d7ac0dd1f",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/editorgroupview.css"
  },
  {
    "revision": "aad9c943b6b36921dce129aeb60df45f",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/editorpicker.css"
  },
  {
    "revision": "df48fd3647de4cdf2e9c744c354a18e7",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/editorstatus.css"
  },
  {
    "revision": "d6980ecce0416786ba9a54bdac3fa65f",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/notabstitlecontrol.css"
  },
  {
    "revision": "96d678ade232edbf3e28dc00cc7aba5b",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/resourceviewer.css"
  },
  {
    "revision": "2a4a50f51eeb3c158d28288e11dd5d61",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/tabstitlecontrol.css"
  },
  {
    "revision": "21f51f5695cf6a23392bf3a1c7827d60",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/titlecontrol.css"
  },
  {
    "revision": "da16857a994dc15a2ba8fc94ecc47b02",
    "url": "lib/vscode/src/vs/workbench/contrib/preferences/electron-browser/media/edit-json.svg"
  },
  {
    "revision": "1589198033f5f1735171939921d7e91a",
    "url": "lib/vscode/src/vs/workbench/contrib/preferences/electron-browser/media/edit-json-inverse.svg"
  },
  {
    "revision": "91e172e53a24485d7b2c620efd9194e8",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/add-inverse.svg"
  },
  {
    "revision": "69e78dd23fbbb02e7f7db6f8d9eb207b",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/breakpoints-activate-inverse.svg"
  },
  {
    "revision": "4d5e128855813628b086a6f372b4e92c",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/clear-repl-inverse.svg"
  },
  {
    "revision": "4392c7760824e2dcf687289b76608ed9",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/configure-inverse.svg"
  },
  {
    "revision": "dca05e86c02a3d7bcf91743b981add7a",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/continue-inverse.svg"
  },
  {
    "revision": "52296971de337d9c49afa9faf68be758",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/disconnect-inverse.svg"
  },
  {
    "revision": "3ed635c53fd70c497d4a3c7d750f4e74",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/pause-inverse.svg"
  },
  {
    "revision": "b7a48fdafd7bf9c69ea960a9439a012f",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/remove-all-inverse.svg"
  },
  {
    "revision": "bd4ab763c713764c310b781e8646dc65",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/repl-inverse.svg"
  },
  {
    "revision": "8f987c636273b5a2a6382a749576f88c",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/restart-inverse.svg"
  },
  {
    "revision": "edb41272d2f0c7e044cc0477b445840f",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/reverse-continue-inverse.svg"
  },
  {
    "revision": "788e632bf37ed7a6faec45a4bf7bdab5",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/start-inverse.svg"
  },
  {
    "revision": "53fe0a817e169c31f8e724b03ce40820",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/step-back-inverse.svg"
  },
  {
    "revision": "15aba4aebe579052fe375dc84cb707f0",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/step-into-inverse.svg"
  },
  {
    "revision": "3f7e2ccf16a9ecfd47f73d051acbf60b",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/step-out-inverse.svg"
  },
  {
    "revision": "0132bb382a96c1c2c7f8d7502cbaeb72",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/step-over-inverse.svg"
  },
  {
    "revision": "e105e91c75f1568e3762fefb25b09b41",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/stop-inverse.svg"
  },
  {
    "revision": "3ed6dcaa1829ec999b6af80ed12bf3a2",
    "url": "lib/vscode/src/vs/workbench/contrib/codeEditor/browser/WordWrap_16x.svg"
  },
  {
    "revision": "b0e13715c5100e397e87440762c9ea6e",
    "url": "lib/vscode/src/vs/editor/browser/widget/media/diagonal-fill.png"
  },
  {
    "revision": "e9f2262c0a150a116032a8bfbdb63325",
    "url": "lib/vscode/src/vs/workbench/contrib/extensions/electron-browser/media/save.svg"
  },
  {
    "revision": "587c3e28760b45d35f054a0ca65d7199",
    "url": "lib/vscode/src/vs/base/browser/ui/octiconLabel/octicons/octicons.ttf"
  },
  {
    "revision": "0edfd291414194a1332fd435c2c3dfe8",
    "url": "lib/vscode/src/vs/platform/extensionManagement/node/media/defaultIcon.png"
  },
  {
    "revision": "94ad7b60c80a53bf22b93d0dfba3962d",
    "url": "lib/vscode/src/vs/editor/contrib/colorPicker/images/opacity-background.png"
  },
  {
    "revision": "b5827721f7f9c00ddad30208e52b43c2",
    "url": "lib/vscode/src/vs/workbench/contrib/webview/electron-browser/webview-pre.js"
  },
  {
    "revision": "0056cbed800fb048a5cc168bc802843c",
    "url": "lib/vscode/src/vs/workbench/browser/parts/quickinput/media/dark/arrow-left.svg"
  },
  {
    "revision": "f8cd2616e38ee4811c7304329f9436b2",
    "url": "lib/vscode/src/vs/workbench/browser/parts/quickinput/media/light/arrow-left.svg"
  },
  {
    "revision": "28c90f3e617a1c675f06defc1b9e21e4",
    "url": "lib/vscode/src/vs/workbench/api/browser/media/test.svg"
  },
  {
    "revision": "12bdc55949748715e99f5a5799a10657",
    "url": "lib/vscode/src/vs/workbench/services/dialogs/browser/media/dark/accept.svg"
  },
  {
    "revision": "e729adb82722b31f5adee53b08b3914d",
    "url": "lib/vscode/src/vs/workbench/services/dialogs/browser/media/dark/folder.svg"
  },
  {
    "revision": "f434a5915c03f66ce7a8af571ddca334",
    "url": "lib/vscode/src/vs/workbench/services/dialogs/browser/media/light/accept.svg"
  },
  {
    "revision": "9d334c98b7d7de7f7f9f42c498c04142",
    "url": "lib/vscode/src/vs/workbench/services/dialogs/browser/media/light/folder.svg"
  },
  {
    "revision": "ef95f9afae2ec3031d498ad33804ddf8",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/close-big-alt.svg"
  },
  {
    "revision": "90694c034fcaf25321b9ce9aac23a310",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/close-big-inverse-alt.svg"
  },
  {
    "revision": "90694c034fcaf25321b9ce9aac23a310",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/close-big-inverse.svg"
  },
  {
    "revision": "ef95f9afae2ec3031d498ad33804ddf8",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/close-big.svg"
  },
  {
    "revision": "00870a6a1bc183d776eec992044b11a6",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/close-dirty-alt.svg"
  },
  {
    "revision": "2b38ca0569bd6f3ba4ff92b88e4db70c",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/close-dirty-inverse-alt.svg"
  },
  {
    "revision": "2b38ca0569bd6f3ba4ff92b88e4db70c",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/close-dirty-inverse.svg"
  },
  {
    "revision": "00870a6a1bc183d776eec992044b11a6",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/close-dirty.svg"
  },
  {
    "revision": "c46fc43b9c2f72ac787dc945169485e5",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/close-inverse.svg"
  },
  {
    "revision": "080770be0c65781d2d78c2cf3791f713",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/close-statusview-inverse.svg"
  },
  {
    "revision": "13576a6174f07fb7e6bb77e9ce1f7056",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/close-statusview.svg"
  },
  {
    "revision": "840447ce5fa717ff73c89548548e0efc",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/close.svg"
  },
  {
    "revision": "b2de1483a14a8ec74243c2d53608c0ad",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/closeall-editors-inverse.svg"
  },
  {
    "revision": "aed18a213fef24630efe43ad5ff6cd55",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/closeall-editors.svg"
  },
  {
    "revision": "f59bd69f36cc3a89bd5f7a4226ffcf6b",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/next-diff-inverse.svg"
  },
  {
    "revision": "0ce058227bec8d4881e803de6cb715e8",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/next-diff.svg"
  },
  {
    "revision": "bc16df5eee665fe1ee75",
    "url": "ide.1.9c27f8.js"
  },
  {
    "revision": "1230325e77acf8ed7e95682c00f95d72",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/paragraph-disabled.svg"
  },
  {
    "revision": "2e6c25eab0ba50c844acd4de133c3cab",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/paragraph-inverse.svg"
  },
  {
    "revision": "328e09e8706f8310bfb482be730e2425",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/paragraph.svg"
  },
  {
    "revision": "6acdeedf8f2d9d08bf1212ee87017e70",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/previous-diff-inverse.svg"
  },
  {
    "revision": "b8db9d927df21e67841031bd8d987cf2",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/previous-diff.svg"
  },
  {
    "revision": "26b95c05d56139869a121e5cda2fda01",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/split-editor-horizontal-inverse.svg"
  },
  {
    "revision": "9ce040f9ba23cfc05a5c69af2efd1f1e",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/split-editor-horizontal.svg"
  },
  {
    "revision": "3e5796cb3b732b4fca85847164fe12c6",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/split-editor-vertical-inverse.svg"
  },
  {
    "revision": "7ae0e6455a72c9870ef7c09967732ef5",
    "url": "lib/vscode/src/vs/workbench/browser/parts/editor/media/split-editor-vertical.svg"
  },
  {
    "revision": "dc6d93227319560b57de7177f82929bb",
    "url": "lib/vscode/src/vs/workbench/contrib/files/browser/media/check.svg"
  },
  {
    "revision": "12bdc55949748715e99f5a5799a10657",
    "url": "lib/vscode/src/vs/workbench/contrib/files/browser/media/check-inverse.svg"
  },
  {
    "revision": "1aee4cc1ae88f40922ecfcfd9b5b43b3",
    "url": "lib/vscode/src/vs/workbench/contrib/files/browser/media/undo.svg"
  },
  {
    "revision": "21eabb610aca2d586ce58bc255dd1157",
    "url": "lib/vscode/src/vs/workbench/contrib/files/browser/media/undo-inverse.svg"
  },
  {
    "revision": "45b27cc2c046c4c60e072bd33f42f5ee",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/add-focus.svg"
  },
  {
    "revision": "f5e497201aafba77c705b232723d4d5e",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/add.svg"
  },
  {
    "revision": "1dc86af2ad6eaad70d8fd138ca89006d",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/breakpoint-conditional-disabled.svg"
  },
  {
    "revision": "c94065fa97c596b856eaa9158b0700dd",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/breakpoint-conditional-unverified.svg"
  },
  {
    "revision": "5a0f10c813433a0b4263e61d4278beee",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/breakpoint-conditional.svg"
  },
  {
    "revision": "23e5f086d30da9f83f9712917177b0bc",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/breakpoint-disabled.svg"
  },
  {
    "revision": "7aa791fe7ec30c05ec420496d6b1d984",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/breakpoint-function-disabled.svg"
  },
  {
    "revision": "e7b414fcd284fdddb09fa198e398babb",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/breakpoint-function-unverified.svg"
  },
  {
    "revision": "563de04b1c5480c97cc8b229c5820f96",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/breakpoint-function.svg"
  },
  {
    "revision": "adb7a4e935f93ba381f3681d1807ede7",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/breakpoint-hint.svg"
  },
  {
    "revision": "53a4cbe69ebfee9dd09c23a93156fbe2",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/breakpoint-log-disabled.svg"
  },
  {
    "revision": "588dcac127cd6df18a466f9965d5d0b3",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/breakpoint-log-unverified.svg"
  },
  {
    "revision": "222cb7e926fe45a2e78825ee93d166d2",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/breakpoint-log.svg"
  },
  {
    "revision": "cb912e308e95a4fff3d1e911b5e9f0b7",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/breakpoint-unsupported.svg"
  },
  {
    "revision": "9ad421d9b315bf8d80b817b87fdc8000",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/breakpoint-unverified.svg"
  },
  {
    "revision": "e6c0654d2fcfef2dd7953320fa9279c0",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/breakpoint.svg"
  },
  {
    "revision": "02bb2e81a3a7d3a5607896890be1a7e9",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/breakpoints-activate.svg"
  },
  {
    "revision": "44e94d449a0315429fff3305195b220f",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/clear-repl.svg"
  },
  {
    "revision": "d6640f9c67f1ec64c39ab62247debdc5",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/configure.svg"
  },
  {
    "revision": "0af579cda843711a04cf380c42d56e2f",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/continue.svg"
  },
  {
    "revision": "6b63b523c342c12dd4a90ffd1e1aafc8",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/current-and-breakpoint.svg"
  },
  {
    "revision": "e77dcb0392c7a68de340a8f57d3fd42d",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/current-arrow.svg"
  },
  {
    "revision": "2d459d1d258c65defbffebb588c8c9f9",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/debug-dark.svg"
  },
  {
    "revision": "e562c0b8cdfe75404fab84964cf575a4",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/disconnect.svg"
  },
  {
    "revision": "3c7b475e2f59b6c139ffd5803eeed949",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/drag.svg"
  },
  {
    "revision": "156e496ddc1c027a0cf891ebfa16eaa8",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/pause.svg"
  },
  {
    "revision": "8257855fd916f00fde8ba424dbfddc97",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/remove-all.svg"
  },
  {
    "revision": "bc529238e48995fec7f400f5da838e7d",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/repl.svg"
  },
  {
    "revision": "1b2eb820e7bab29c6f2e498b3fdbfb27",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/restart.svg"
  },
  {
    "revision": "471b7ae16c501c4b5aac87f898a99b19",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/reverse-continue.svg"
  },
  {
    "revision": "f69c21b4a5adf41e8fd40f63946c5bdf",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/stackframe-and-breakpoint.svg"
  },
  {
    "revision": "baad49f46e8a5bf9631f00bb9715ebac",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/stackframe-arrow.svg"
  },
  {
    "revision": "59c710a654e7c8150f459f4cc3cde071",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/start.svg"
  },
  {
    "revision": "a09a582bb38906fec98b8914f89001b8",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/step-back.svg"
  },
  {
    "revision": "c7295003f3a9925234c43ba0a1866382",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/step-into.svg"
  },
  {
    "revision": "e671168663d7838399485f2e5678cb50",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/step-out.svg"
  },
  {
    "revision": "269d07d2c1ec422d87c714e493df89a1",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/step-over.svg"
  },
  {
    "revision": "4d6f3b618970fc65708813445ae9860e",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/browser/media/stop.svg"
  },
  {
    "revision": "e88faa078246779ffa25b600cfd4f7f0",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/electron-browser/media/continue-tb.png"
  },
  {
    "revision": "63e98753e14dcd8f7592deb4ed2f0b28",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/electron-browser/media/continue-without-debugging-tb.png"
  },
  {
    "revision": "0ba2ca9e7850f2767b84ad9db24fa0af",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/electron-browser/media/pause-tb.png"
  },
  {
    "revision": "90c723f09c419390a0f88726f0cb8c7a",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/electron-browser/media/restart-tb.png"
  },
  {
    "revision": "a0dd32b7800a7b9fd7da12241c3c85b4",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/electron-browser/media/stepinto-tb.png"
  },
  {
    "revision": "f35635b3980fcc42ad5ce56dce26f43b",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/electron-browser/media/stepout-tb.png"
  },
  {
    "revision": "6a3fd3aec6f47641ca874678bee63178",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/electron-browser/media/stepover-tb.png"
  },
  {
    "revision": "80f44d5d59f10b7d60ec77f3adfc4315",
    "url": "lib/vscode/src/vs/workbench/contrib/debug/electron-browser/media/stop-tb.png"
  },
  {
    "revision": "8069970a5ba7bcd77e423f21050a873d",
    "url": "lib/vscode/src/vs/workbench/contrib/extensions/electron-browser/media/theme-icon.png"
  },
  {
    "revision": "902888d212ed4c6d024432880c46b068",
    "url": "lib/vscode/src/vs/workbench/contrib/extensions/electron-browser/media/language-icon.svg"
  },
  {
    "revision": "dc40ddb3b11b95bbf1a577d599c9ff19",
    "url": "lib/vscode/src/vs/workbench/contrib/extensions/electron-browser/media/defaultIcon.png"
  },
  {
    "revision": "b904a239cee230359d25059943441820",
    "url": "lib/vscode/src/vs/workbench/contrib/update/electron-browser/media/markdown.css"
  },
  {
    "revision": "ff397a9fbfbae660f6643f7c3da69490",
    "url": "lib/vscode/src/vs/workbench/contrib/update/electron-browser/media/code-icon.svg"
  },
  {
    "revision": "81849defdbd0019759444e16e89627d7",
    "url": "lib/vscode/src/vs/workbench/contrib/extensions/electron-browser/media/markdown.css"
  },
  {
    "revision": "788e632bf37ed7a6faec45a4bf7bdab5",
    "url": "lib/vscode/src/vs/workbench/contrib/extensions/electron-browser/media/start-inverse.svg"
  },
  {
    "revision": "59c710a654e7c8150f459f4cc3cde071",
    "url": "lib/vscode/src/vs/workbench/contrib/extensions/electron-browser/media/start.svg"
  },
  {
    "revision": "2ac1196dfff8d6b7374756bc6162eaf9",
    "url": "lib/vscode/src/vs/workbench/contrib/extensions/electron-browser/media/profile-start-inverse.svg"
  },
  {
    "revision": "1a0e1c0d5e6ddf5429e437ca8732465c",
    "url": "lib/vscode/src/vs/workbench/contrib/extensions/electron-browser/media/profile-start.svg"
  },
  {
    "revision": "4c647331055cf012fb18518668ff6e10",
    "url": "lib/vscode/src/vs/workbench/contrib/extensions/electron-browser/media/profile-stop-inverse.svg"
  },
  {
    "revision": "d7ead66a247253533764937e9f46cf7c",
    "url": "lib/vscode/src/vs/workbench/contrib/extensions/electron-browser/media/profile-stop.svg"
  },
  {
    "revision": "ab7db309e1aea27eb25eecce2609ae2f",
    "url": "lib/vscode/src/vs/workbench/contrib/extensions/electron-browser/media/save-inverse.svg"
  },
  {
    "url": "icon_96x96.466b33991be22d980536395966dd672c.png"
  },
  {
    "url": "icon_384x384.a0eefc92ec4f6380ffeb7ffe7722518a.png"
  },
  {
    "url": "icon_256x256.1a57ac49aad5fcf6ecafa46b56b13980.png"
  },
  {
    "url": "icon_192x192.985889394ac7b880177bb373fcbdefd9.png"
  },
  {
    "url": "icon_128x128.912e71a6ce283b4deaa84da982721fe3.png"
  },
  {
    "url": "f8f821a66b20e5801e35df5ec4565b30.wasm"
  }
]);